// UNIX
mongo src/Database/Init.ts
// Windows 10
"C:\Program Files\MongoDB\Server\4.0\bin\mongo.exe" src\Database\Init.ts
