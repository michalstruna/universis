React.createClass('MyComponent', {
    children: 'Hello ' + name + '!',
    className: 'block'
})

<MyComponent className='block'>
    Hello {name}!
</MyComponent>
