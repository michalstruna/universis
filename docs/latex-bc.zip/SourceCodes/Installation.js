// UNIX
npm run-script build-and-run
// Windows 10
npm run-script build-and-run-windows
