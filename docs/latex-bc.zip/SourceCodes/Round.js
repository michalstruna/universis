Units.toShort(1234.567890) // 1.23k
Units.toShort(123.4567890) // 123
Units.toShort(12.3456790) // 12.3
Units.toShort(1.234567890) // 1.23
Units.toShort(0.0001234567890) // 0.0001
